// ==
// console.log(2 == 2);
// console.log(3 = 2);
// console.log(2 == '2');  //ohne datatype
// console.log( 2 === "2") // Mit datatype

// console.log(2 != 2);
// console.log(3 != 2 );
// console.log( 2 != '2');
// console.log(2 !== '2');
// console.log(2 !== 2);

// >
// console.log(2 > 2);
// console.log(3 > 2);

// <

// console.log(2 < 2);
// console.log(3 < 4);


// >=
// console.log(2 >= 2);
// console.log( 3 >= 2 );


// <=
// console.log(4 <= 3);
// console.log(3 <= 4);


