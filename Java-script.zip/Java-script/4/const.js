// var PI = 3.1415;
// console.log(PI);
// PI = 15;
// console.log(PI);


// const PII = 3.1415;
// console.log(PII);
// PII = 15;
// console.log(PII);



