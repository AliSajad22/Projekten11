var a = 10 + 2;
console.log(a);
console.log(typeof a);


var b = '5' + '10';
console.log(b);
console.log(typeof b);


var c = 'Ali'
var d = 'Enayat'
var e = c + d;
console.log(e);
console.log( typeof e);



var f = 2 + 2 + 'ali';
console.log(f);
console.log(typeof f);


var g = 'ali' + 2 + 2;
console.log(g);
console.log(typeof g);


var aa = 10;
console.log(aa);
console.log(aa++)


var aaa = 100;
console.log(aaa);
console.log(aaa++);









