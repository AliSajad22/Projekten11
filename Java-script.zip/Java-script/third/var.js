// var a = 5;
// var b = 10;
// var c = a + b;
// console.log(c);
// var firstname = 'alisajad' ;
// console.log(firstname);
// var a = 5;
// console.log(a);

// Das Variable erstes videos 


