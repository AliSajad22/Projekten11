// let Input1 = document.getElementById('first');
// let Input2 = document.getElementById('second');
// let Button = document.getElementById('btn');
// let Gesamt = document.getElementById('total');

// Button.onclick = function(){
//     let first = Number(Input1.value)
//     let second = Number(Input2.value)
//     let result = 0

//     if(first > second){
//         alert('die Zhal sollte klein als zweite zahle sein ');
//     } else{

//         while(first <= second){
//             total += first
//             first++
//         } 
        
//     }
//     if(erstezahl > 0){
//         total.innerText = result.toLocaleString()
//     }

        
// }
