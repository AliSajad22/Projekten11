// var firstname = document.getElementById('name')
// console.log(firstname.value);