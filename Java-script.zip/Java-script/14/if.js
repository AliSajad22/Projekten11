// let button = document.getElementById('button');

// let age = document.getElementById('name');

// button.onclick= function(){
//     if(age.value >= 18){
//         alert('Du bist volljährig')
//     }

//     if(age.value < 18){
//         alert('Du bist mindestjährig')
//     }
// }

