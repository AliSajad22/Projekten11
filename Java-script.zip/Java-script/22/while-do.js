var num = 1;
while( num <= 5){
    console.log('alisajad');
    num++;
}


var numb = 1;
do{
    console.log('ali');
    numb++;

}
while( num <= 5);




var numbe = 5;
while( numbe >= 1){
    console.log('numbe');
    numbe--;
}



var number = 5;
do{
    console.log('number');
    number--
}
while(number >= 1);





