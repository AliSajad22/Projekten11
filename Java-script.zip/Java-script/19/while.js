// var num = 5;
// while( num <= 10){
//     console.log('num')
//     num++
// }


// var num2 = 300;
// while(num2 <= 400){
//     if (num2 %7 ==0){
//         console.log(num2)
//     }
//     num2++
// }  


// var sum = 0 , i = 1 ;
// while(i <= 5){
//     sum += i;
//     i++;
// }

// console.log('Gesamt' + sum);
// console.log(i);