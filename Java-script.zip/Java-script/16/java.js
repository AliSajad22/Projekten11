// var numberInput = document.getElementById('num');

// var button = document.getElementById('btn');

// button.onclick = function(){
//     if(numberInput.value %2 == 0){
//         alert('Das ist eine Gerade Zahl')
//     } else{
//         alert('Das ist eine Ungerade Zahl')
//     }
// }




// var numberInput = document.getElementById('num');
// var buttonn = document.getElementById('btn');
// var result = document.getElementById('resultBox');

// buttonn.onclick = function(){
//     if(numberInput.value %2 == 0){
//         result.innerText = 'Das ist eine gerade Zahl'
//     } else{
//         result.innerText = 'Das ist eine Ungerade Zahl'
//     }
// }