// var a = true;
// console.log(a);

// var b = false;
// console.log(b);

// var c = (20>19);
// console.log(c);

// var age = 20;
// console.log(age>22);




