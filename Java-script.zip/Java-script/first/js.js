// document.getElementById('ali').innerHTML = 'Ali-Sajad-Enayat';
// document.write('Das ist meine Erste java datei ');
// window.alert('das ist alert')
// console.log('ali sajad enayat');

