// var name = "Ali Sajad 'Enayat'";
// console.log(name);


// var name = "Ali Sajad 'Enayat'";
// console.log(name.length);
