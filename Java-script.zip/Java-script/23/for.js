let numInput = document.getElementById("number")
let result = document.getElementById("result")
let computebtn = document.getElementById("compute")

computebtn.onclick = function(){
    let num = Number(numInput.value)
    let conter = 0
}