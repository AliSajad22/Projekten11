// var age = 25;

// if(age > 18){
//     console.log('Du bist 18')
// }

// else{
//     console.log('Du bist unter 18')
// }

// 2222222

// var num = 20;
// if(num > 0){
//     console.log(num);
// }
// else{
//     console.log(-num);
// }


// var num = -20;
// if(num > 0){
//     console.log(num);
// }
// else{
//     console.log(-num);
// }


// 3333333

// var num = 13;
// if (num % 2 == 0) {
//     console.log('gerade')
// }

// else{
//     console.log('ungerade')
// }



// var num = 20;
// if (num % 2 == 0) {
//     console.log('gerade')
// }

// else{
//     console.log('ungerade')
// }



