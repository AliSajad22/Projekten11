// var a = 100;
// var b = 150;
// var c = a + b;
// console.log(c);


// var a = 150;
// var b = 100;
// var c = a - b;
// console.log(c);



// var a = 150;
// var b = 100;
// var c = a * b;
// console.log(c);




// var a = 150;
// var b = 100;
// var c = a / b;
// console.log(c);


