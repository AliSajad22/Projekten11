var Tage = 2;

switch (Tage) {
    case 1:
        console.log('Montag')
        break;

        case 2:
            console.log('Dienstag')
            break;


            case 3:
                console.log('Mittowoch')
                break;


                case 4:
                    console.log('Donnerstag')
                    break;


                    case 5:
                        console.log('Freitag')
                        break;

                        case 6:
                            console.log('Samstag')
                            break;

                            case 7:
                                console.log('sonntag')
                                break;

                                default:
                                    console.log('Nicht erkannt');
}