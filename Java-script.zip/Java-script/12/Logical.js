// // && // is und II or und ! is not ;

// var age = 20;
// // Überprüfung, ob Alter größer als 18 ist
// if (age > 18) {
//     console.log('Herzlich willkommen');
// }
// // Namen in der Konsole ausgeben
// console.log('Ali Sajad Enayat');



// var age = 10;
// // Überprüfung, ob Alter größer als 18 ist
// if (age > 18) {
//     console.log('Herzlich willkommen');
// } else {
//     console.log('Du bist unter 18');
// }
// // Namen in der Konsole ausgeben
// console.log('Ali Sajad Enayat');








