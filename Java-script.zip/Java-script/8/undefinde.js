// var a = 250 ;
// console.log(typeof a);

// var naem = 'ali';
// console.log(typeof naem)

// var a = true;
// console.log(typeof a);

// var f;
// console.log(f);a